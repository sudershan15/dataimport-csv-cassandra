package SecurityDecorator;

class Mergable extends SecurityDecorator{

	public Mergable(Security sec) {
		super(sec);
		// TODO Auto-generated constructor stub
	}
	
	public void display(){
		super.display();
	}
}