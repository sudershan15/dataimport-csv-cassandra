package com.guidewire.wordy.impl;

import com.guidewire.wordy.IWordValidator;
import com.guidewire.wordy.IWordInBoardValidator;
import com.guidewire.wordy.IBoard;
import com.guidewire.wordy.IWordScorer;
import junit.framework.TestCase;

import java.util.Arrays;
import java.util.List;

public class WordyImplTest extends TestCase {

  public void testScoreWordsCountsWordsThatAreBothValidAndInBoard() {
    // Please fill out implementation
    fail("Not implemented");
  }

  public void testScoreWordsCountsDuplicatesOnlyOnce() {
    // Please fill out implementation
    fail("Not implemented");
  }

  public void testScoreWordsWithLeadingAndTrailingSpaces() {
    // Please fill out implementation
    fail("Not implemented");
  }

  public void testScoreWordsDoesNotCountWordsThatAreValidButNotInBoard() {
    // Please fill out implementation
    fail("Not implemented");
  }

  // Add your own test cases here
}
