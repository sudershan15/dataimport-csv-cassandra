package CLIENT;

import Requestmanager.Manager;

public class client{
	public static void main(String[] args){
		Manager m=new Manager();
		
	}
}