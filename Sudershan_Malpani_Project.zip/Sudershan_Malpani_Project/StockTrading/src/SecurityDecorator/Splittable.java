package SecurityDecorator;

class Splitable extends SecurityDecorator{

	public Splitable(Security sec) {
		super(sec);
		// TODO Auto-generated constructor stub
	}
	
	public void split(int num){
		
	}
	
	public void display(){
		super.display();
	}
}