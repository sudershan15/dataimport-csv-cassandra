**Description about the project and Snapshots in Final_Report_spring_v.1.2**

FrontEnd: Struts Framework 
Middle Layer: Spring Framework
BackEnd: MySQL

Servers Used: JBoss, Apache Tomcat

