package com.guidewire.wordy.impl;

import com.guidewire.wordy.IBoard;
import com.guidewire.wordy.util.ArgCheck;
import junit.framework.TestCase;

public class WordInBoardValidatorImplTest extends TestCase {

  // Please add your own tests here

}
