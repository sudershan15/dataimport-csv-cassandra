The project does the searching of places like Restaurants, Movies and Movie Theatres, News and Events around a particular Zip Code. It is made using Web Services like SOAP. It contains a WSDL File. Database Used in the project is Cassandra. The project was deployed in a top-down approach using Ant Build (build.xml).

Frontend: JSP's and Servlets
Backend: Cassandra

Servers: Apache Tomcat