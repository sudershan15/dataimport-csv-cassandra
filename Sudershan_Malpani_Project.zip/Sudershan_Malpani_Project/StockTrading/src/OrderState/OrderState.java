package OrderState;

public interface OrderState {
    public abstract String processingOrder();
}
